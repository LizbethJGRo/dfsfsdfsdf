from django.contrib import admin
from axel_app.models import *


admin.site.register(Vehicle)
admin.site.register(Recall)
admin.site.register(ServiceType)
admin.site.register(ServiceRecord)

