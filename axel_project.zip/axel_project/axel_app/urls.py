from django.urls import path

from axel_app.views import *

urlpatterns = [
    path("my-vehicles/", MyVehicles.as_view(), name="my_vehicles"),
    path("add-vehicle/", AddVehicle, name="add_vehicle"),
    path("edit-vehicle/<int:pk>/", EditVehicle, name="edit_vehicle"),
    path('add-service-record/<int:vehicle_id>/', AddServiceRecord, name='add_service_record'),
    path("upload-documents/<int:service_record_id>/", upload_supporting_documents, name="upload_documents"),
    path("delete-document/<int:document_id>/", delete_supporting_document, name="delete_document"),
    path("delete-document/<int:document_id>/", delete_supporting_document, name="delete_document"),
    path('service_map/', MapView, name='service_map'),
]

