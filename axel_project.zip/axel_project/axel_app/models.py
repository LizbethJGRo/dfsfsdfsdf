from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin


class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("The Email field must be set")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        return self.create_user(email, password, **extra_fields)


class CustomUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    USERNAME_FIELD = 'email'  # Primary identifier for authentication
    REQUIRED_FIELDS = []  # No additional required fields

    objects = CustomUserManager()

    def __str__(self):
        return self.email


class Vehicle(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    vin = models.CharField(max_length=17)
    make = models.CharField(max_length=50)
    model = models.CharField(max_length=50)
    photo = models.ImageField(upload_to="car_profiles_photos", null=True, blank=True)
    year = models.PositiveIntegerField()
    drive = models.CharField(max_length=10, null=True, blank=True)
    trim = models.CharField(max_length=100, null=True, blank=True)
    body_class = models.CharField(max_length=100, null=True, blank=True)
    date_added = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "vin")

    def __str__(self):
        return f"{self.make} {self.model} ({self.year})"


class Recall(models.Model):
    make = models.CharField(max_length=50)
    model = models.CharField(max_length=50)
    year = models.PositiveIntegerField()
    manufacturer = models.CharField(max_length=100)
    nhtsa_recall_number = models.CharField(max_length=20, unique=True)
    component = models.CharField(max_length=100)
    park_it = models.BooleanField(default=False)
    park_out_side = models.BooleanField(default=False)
    report_received_date = models.DateField(null=True, blank=True)
    summary = models.TextField(null=True, blank=True)
    consequence = models.TextField(null=True, blank=True)
    remedy = models.TextField(null=True, blank=True)
    notes = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"Recall {self.nhtsa_recall_number} for {self.make}, {self.model}, {self.year}"


class ServiceType(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)
    parent = models.ForeignKey(
        'self', on_delete=models.CASCADE, null=True, blank=True, related_name='subtypes'
    )

    def __str__(self):
        return self.name


class SupportingDocument(models.Model):
    service_record = models.ForeignKey('ServiceRecord', on_delete=models.CASCADE)
    document = models.FileField(upload_to="supporting_documents")

    def __str__(self):
        return f"Document for {self.service_record}"


class ServiceRecord(models.Model):
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE)
    recall = models.ForeignKey(Recall, on_delete=models.SET_NULL, null=True, blank=True)
    service_type = models.ManyToManyField(ServiceType)
    date_of_service = models.DateField()
    description = models.TextField()

    def __str__(self):
        return f"Service on {self.date_of_service} for {self.vehicle}"
