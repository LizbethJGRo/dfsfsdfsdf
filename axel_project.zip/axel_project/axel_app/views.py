from django.http import JsonResponse
from django.views.generic.edit import FormView
from django.views.generic import TemplateView
from django.contrib import messages
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction

from .forms import CustomUserCreationForm, SupportingDocumentForm
from .models import Vehicle, ServiceRecord, Recall, ServiceType, SupportingDocument

import requests
import json
from datetime import datetime


def MapView(request):
    return render(request, "views/service_map.html")


class RegisterView(FormView):
    template_name = 'registration/register.html'
    form_class = CustomUserCreationForm
    success_url = reverse_lazy('login')

    def form_valid(self, form):
        form.save()
        return super().form_valid(form)


class MyVehicles(TemplateView):
    template_name = "views/my_vehicles.html"

    @staticmethod
    def fetch_recalls_from_nhtsa(make, model, year):
        """Fetch recalls from the NHTSA API."""
        nhtsa_api_url = f"https://api.nhtsa.gov/recalls/recallsByVehicle?make={make}&model={model}&modelYear={year}"
        try:
            response = requests.get(nhtsa_api_url)
            response.raise_for_status()
            data = response.json()
            print("Response:", data)
            return [
                {
                    "nhtsa_recall_number": recall.get("NHTSACampaignNumber"),
                    "component": recall.get("Component"),
                    "park_it": recall.get("parkIt", False),
                    "park_out_side": recall.get("parkOutSide", False),
                    "report_received_date": recall.get("ReportReceivedDate"),
                    "summary": recall.get("Summary"),
                    "consequence": recall.get("Consequence"),
                    "remedy": recall.get("Remedy"),
                    "notes": recall.get("Notes"),
                    "manufacturer": recall.get("Manufacturer"),
                }
                for recall in data.get("results", [])
            ]
        except requests.RequestException:
            # Handle API errors gracefully
            return []

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # Get the user's vehicles
        user_vehicles = Vehicle.objects.filter(user=self.request.user)

        # Prepare data for each vehicle
        vehicles_data = []
        for vehicle in user_vehicles:
            # Fetch serviced recall IDs for this vehicle
            serviced_recalls = set(
                ServiceRecord.objects.filter(vehicle=vehicle).values_list("recall__nhtsa_recall_number", flat=True))

            # Fetch recalls from the NHTSA API
            nhtsa_recalls = self.fetch_recalls_from_nhtsa(make=vehicle.make, model=vehicle.model, year=vehicle.year)

            # Add new recalls to the database if they don't exist
            new_recalls = []
            with transaction.atomic():
                for recall in nhtsa_recalls:
                    nhtsa_number = recall["nhtsa_recall_number"]

                    # Check if recall exists in the database
                    recall_obj, created = Recall.objects.get_or_create(
                        nhtsa_recall_number=nhtsa_number,
                        defaults={
                            "make": vehicle.make,
                            "model": vehicle.model,
                            "year": vehicle.year,
                            "manufacturer": recall.get("manufacturer"),
                            "component": recall.get("component"),
                            "park_it": recall.get("park_it", False),
                            "park_out_side": recall.get("park_out_side", False),
                            "report_received_date": datetime.strptime(recall.get("report_received_date"), "%d/%m/%Y").strftime("%Y-%m-%d"),
                            "summary": recall.get("summary"),
                            "consequence": recall.get("consequence"),
                            "remedy": recall.get("remedy"),
                            "notes": recall.get("notes"),
                        },
                    )
                    if created:
                        new_recalls.append(recall_obj)

            # Filter recalls to only include those not yet serviced
            unserviced_recalls = Recall.objects.filter(
                nhtsa_recall_number__in=[recall["nhtsa_recall_number"] for recall in nhtsa_recalls]
            ).exclude(nhtsa_recall_number__in=serviced_recalls).values(
                "make",
                "model",
                "year",
                "manufacturer",
                "park_it",
                "park_out_side",
                "report_received_date",
                "nhtsa_recall_number",
                "component",
                "summary",
                "consequence",
                "remedy",
                "notes"
            )

            # Fetch service records for this vehicle
            service_records = ServiceRecord.objects.filter(vehicle=vehicle).values(
                "date_of_service", "service_type__name", "description"
            )

            vehicles_data.append({
                "vehicle": {
                    "photo": vehicle.photo.url if vehicle.photo else None,
                    "id": vehicle.id,
                    "make": vehicle.make,
                    "model": vehicle.model,
                    "year": vehicle.year,
                    "vin": vehicle.vin,
                },
                "recalls": list(unserviced_recalls),
                "service_records": list(service_records),
                "new_recalls_added": [recall.nhtsa_recall_number for recall in new_recalls],
            })

        context["vehicles_data"] = vehicles_data
        return context


def AddVehicle(request):
    if request.method == "POST":
        vin = request.POST.get("vin")
        if not vin or len(vin) != 17:
            messages.error(request, "Invalid VIN. Please enter a valid 17-character VIN.")
            return redirect("add_vehicle")

        # Call NHTSA API
        api_url = f"https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVin/{vin}?format=json"
        response = requests.get(api_url)
        if response.status_code != 200:
            messages.error(request, "Error fetching data from the NHTSA API.")
            return redirect("add_vehicle")

        data = response.json()
        results = {item['Variable']: item['Value'] for item in data.get('Results', [])}

        # Create a vehicle with fetched data, leave others as None
        vehicle = Vehicle.objects.create(
            user=request.user,
            vin=vin,
            make=results.get("Make", None),
            model=results.get("Model", None),
            year=int(results.get("Model Year", 0)) if results.get("Model Year") else None,
            drive=results.get("Drive Type", None),
            trim=results.get("Trim", None),
            body_class=results.get("Body Class", None),
        )
        vehicle.save()

        # Redirect to the edit page to allow filling in missing fields
        return redirect("edit_vehicle", pk=vehicle.pk)

    return render(request, "views/add_vehicle.html")


def EditVehicle(request, pk):
    vehicle = get_object_or_404(Vehicle, pk=pk)

    if request.method == "POST":
        # Update the vehicle with user-provided data
        vehicle.make = request.POST.get("make") or None
        vehicle.model = request.POST.get("model") or None
        vehicle.year = request.POST.get("year") or None
        vehicle.drive = request.POST.get("drive") or None
        vehicle.trim = request.POST.get("trim") or None
        vehicle.body_class = request.POST.get("body_class") or None
        vehicle.photo = request.FILES.get("photo") if "photo" in request.FILES else vehicle.photo
        vehicle.save()

        messages.success(request, "Vehicle updated successfully!")
        return redirect("my_vehicles")

    return render(request, "views/edit_vehicle.html", {"vehicle": vehicle})


def AddServiceRecord(request, vehicle_id):
    # Get the vehicle based on the ID
    vehicle = get_object_or_404(Vehicle, id=vehicle_id)

    if request.method == "POST":
        # Get form data
        print(request.POST)
        recall_id = request.POST.get("recall")
        service_types_raw = request.POST.get("service_types")  # Get the raw string value
        try:
            service_types = json.loads(service_types_raw)  # Parse JSON into a Python list
        except json.JSONDecodeError:
            messages.error(request, "Invalid service types format.")
            return redirect("add_service_record", vehicle_id=vehicle_id)

        date_of_service = request.POST.get("date_of_service")

        description = request.POST.get("description")

        # Get related objects
        recall = Recall.objects.get(id=recall_id) if recall_id else None

        # Validate service types
        selected_service_types = ServiceType.objects.filter(id__in=service_types)
        if not selected_service_types.exists():
            messages.error(request, "Please select valid service types.")
            return redirect("add_service_record", vehicle_id=vehicle_id)

        # Create the service record
        service_record = ServiceRecord(
            vehicle=vehicle,
            recall=recall,
            date_of_service=date_of_service,
            description=description,
        )
        service_record.save()

        # Add selected service types to the service record
        service_record.service_type.add(*selected_service_types)

        # Save supporting images

        # Save supporting documents
        for document in request.FILES.getlist("supporting_documents"):
            SupportingDocument.objects.create(service_record=service_record, document=document)

        messages.success(request, "Service record added successfully!")
        return redirect("add_service_record", vehicle_id=vehicle_id)

    # Populate dropdown options
    recalls = Recall.objects.filter(make=vehicle.make, model=vehicle.model, year=vehicle.year)

    # Prepare service types for parent-child structure
    service_types = ServiceType.objects.prefetch_related("subtypes").all()
    service_types_hierarchy = []
    for parent in service_types.filter(parent__isnull=True):
        service_types_hierarchy.append({
            "id": parent.id,
            "name": parent.name,
            "subtypes": [
                {"id": child.id, "name": child.name}
                for child in parent.subtypes.all()
            ]
        })

    # Prepare context
    context = {
        "vehicle": {
            "id": vehicle.id,
            "make": vehicle.make,
            "model": vehicle.model,
            "year": vehicle.year,
            "vin": vehicle.vin,
            "photo": vehicle.photo.url if vehicle.photo else None,
        },
        "recalls": list(recalls.values(
            "id", "nhtsa_recall_number", "component", "summary"
        )),
        "service_types_hierarchy": service_types_hierarchy,
    }

    return render(request, "views/add_service_record.html", context)


def upload_supporting_documents(request, service_record_id):
    service_record = get_object_or_404(ServiceRecord, id=service_record_id)

    if request.method == "POST":
        form = SupportingDocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save(service_record)
            messages.success(request, "Documents uploaded successfully.")
        else:
            messages.error(request, "Failed to upload documents.")

    return redirect("upload_documents", service_record_id=service_record.id)


def delete_supporting_document(request, document_id):
    if request.method == "POST":
        try:
            document = SupportingDocument.objects.get(id=document_id)
            document.delete()
            return JsonResponse({"success": True})
        except SupportingDocument.DoesNotExist:
            return JsonResponse({"success": False, "error": "Document not found"}, status=404)
    return JsonResponse({"success": False, "error": "Invalid request method"}, status=400)