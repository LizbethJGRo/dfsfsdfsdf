/** @type {import('tailwindcss').Config} */
import daisyui from "daisyui"

module.exports = {
    content: ["./templates/**/*.html", "./**/templates/**/*.html"],
    theme: {
        extend: {},
    },
    plugins: [
        daisyui
    ],
    daisyui: {
        themes: [
            "light",
            "dark"
        ]
    },
}

