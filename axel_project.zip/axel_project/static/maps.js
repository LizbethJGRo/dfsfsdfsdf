let map;
let center = { lat: 18.054698, lng: -66.506070 }; // Center for the map
let radius = 20000; // Radius in meters

async function initMap() {
  const { Map } = await google.maps.importLibrary("maps");
  const { Place } = await google.maps.importLibrary("places");
  const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");

  // Initialize the map
  map = new Map(document.getElementById("map"), {
    center: center,
    zoom: 13,
    mapId: "DEMO_MAP_ID",
  });

  // Find places within the specified radius
  await findPlaces();
}

async function findPlaces() {
  const { Place } = await google.maps.importLibrary("places");

  // Define LatLngBounds for results
  const bounds = new google.maps.LatLngBounds();

  const request = {
    textQuery: "Toyota", // Search query
    fields: ["displayName", "location", "formattedAddress", "internationalPhoneNumber"],
    locationBias: center, // Bias search results around the center
    maxResultCount: 5,
    minRating: 3.5,
    includedType: "car_dealer",
  };

  try {
    const { places } = await Place.searchByText(request);

    if (places.length) {
      console.log(`Found ${places.length} places.`);
      displayPlacesOnMap(places, bounds);
    } else {
      console.log("No results found.");
    }
  } catch (error) {
    console.error("Error fetching places:", error);
  }
}

function displayPlacesOnMap(places, bounds) {
  const infoWindow = new google.maps.InfoWindow(); // Create InfoWindow instance

  places.forEach((place) => {
    // Add marker for each place
    const marker = new google.maps.marker.AdvancedMarkerElement({
      map,
      position: place.location,
      title: place.displayName,
    });

    // Add marker click event
    customElements.whenDefined(marker.localName).then(() => {
      marker.addEventListener("gmp-click", () => {
        const content = `
          <h3>${place.displayName}</h3>
          <p><strong>Address:</strong> ${place.formattedAddress || "N/A"}</p>
          <p><strong>Phone:</strong> ${place.internationalPhoneNumber || "N/A"}</p>
        `;
        infoWindow.setContent(content);
        infoWindow.open({ anchor: marker, map });
      });
    });

    // Extend LatLngBounds to include this marker
    bounds.extend(place.location);
  });

  // Adjust map to fit all markers
  map.fitBounds(bounds);
}

// Initialize the map
initMap();
